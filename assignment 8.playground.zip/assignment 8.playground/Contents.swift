import UIKit

var greeting = "Hello, playground"

//1
class ControlCenter: StationModule {
    public var isLockedDown: Bool
    var securityCode: String
    
    init(isLockedDown: Bool, securityCode: String, moduleName: String) {
        self.isLockedDown = isLockedDown
        self.securityCode = securityCode
        super.init(moduleName: moduleName)
    }
    
    func lockdown(password: String) -> Bool {
        if password == securityCode {
            return true
        } else {
            return false
        }
    }
}

//2

class ResearchLab: StationModule {
    var samplesArray: [String] = []
    
    init(samplesArray: [String], moduleName: String) {
        self.samplesArray = samplesArray
        super.init(moduleName: moduleName)

    }
    
    func addSample(sample: String) {
        samplesArray.append(sample)
    }
}


//3
class LifeSupportSystem: StationModule {
    var oxygenLevel: Int
    
    init(oxygenLevel: Int, moduleName: String) {
        self.oxygenLevel = oxygenLevel
        super.init(moduleName: moduleName)

    }
    
    func oxygenStatus() -> String {
        if oxygenLevel>=90 {
            print("oxygen level is high")
            return "high"
        } else if oxygenLevel>=60 {
            print("oxygen level is normal")
            return "normal"
        } else {
            print("oxygen level is low")
            return "low"
        }
    }
}

//4
class StationModule {
    var moduleName: String
    var drone: Drone?
    
    init(moduleName: String, drone: Drone? = nil) {
        self.moduleName = moduleName
        self.drone = drone
    }
    
    func giveDroneTask(task: String) {
        if let drone = drone {
            drone.task = task //maybe i needed optional here, since this type is optional value
            print("task: \(task) is given to drone")
        } else {
            print("there is no drone to give a task")
        }
    }
    
}

//6

class Drone {
    var task: String?
    unowned var assignedModule: StationModule
    weak var missionControlLink: MissionControl?
    
    init(task: String? = nil, assignedModule: StationModule, missionControlLink: MissionControl? = nil) {
        self.task = task
        self.assignedModule = assignedModule
        self.missionControlLink = missionControlLink
    }
    
    func hasDroneTask() -> Bool {
        if let task = task {
            print("drone has task")
            return true
            
        } else {
            print("drone doesnt have a task")
            return false
        }
    }
    
}// ეს არ იმუშავებს ჯერ, დასაკავშირებელი მაქვს

//7

class OrbitronSpaceStation {
    var controlCenter: ControlCenter
    var researchLab: ResearchLab
    var lifesupportSystem: LifeSupportSystem
    var isLockedDown: Bool
    var securityCode: String
    
    init(controlCenter: ControlCenter, researchLab: ResearchLab, lifesupportSystem: LifeSupportSystem, isLockedDown: Bool, securityCode: String) {
        self.controlCenter = controlCenter
        self.researchLab = researchLab
        self.lifesupportSystem = lifesupportSystem
        self.isLockedDown = false
        self.securityCode = securityCode
    }
    
    func lockControlCenter() {
        controlCenter.isLockedDown = true
    }
}

//8

class MissionControl: OrbitronSpaceStation {
    var spaceStation: OrbitronSpaceStation?
    
    
    func connectToOrbitronSpaceStation(spaceStation: OrbitronSpaceStation) {
        self.spaceStation = spaceStation
        print("connection to Orbitron Space Station is created")
        
    }
    
    func requestControlCenterStatus() {
        if let controlCenter = spaceStation?.controlCenter {
            print("Control center status:")
            controlCenter.drone?.hasDroneTask()
        }
    }
    
    
    
    func requestOxygenStatus() {
        if let lifesupportSystem = spaceStation?.lifesupportSystem {
            print("oxygen status is: \(lifesupportSystem.oxygenStatus())")
        }
    }
    
    func requestDroneStatus() {
        
    }
    
    
}




